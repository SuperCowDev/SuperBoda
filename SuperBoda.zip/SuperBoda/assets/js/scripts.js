function OpenCamera() {

    document.getElementById("camera").style.display = "block";
    document.getElementById("init").style.display = "none";

    var video = document.querySelector("#videoElement");

    if (navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ video: true })
            .then(function (stream) {
                video.srcObject = stream;
            })
            .catch(function (error) {
                console.log("Something went wrong!" + error);
            });
    }
    setTimeout(() => { stopCam() }, 3500);
}

function stopCam(e) {
    var video = document.querySelector("#videoElement");
    var stream = video.srcObject;
    var tracks = stream.getTracks();

    for (var i = 0; i < tracks.length; i++) {
        var track = tracks[i];
        track.stop();
    }
    video.srcObject = null;

    document.getElementById("camera").style.display = "none";
    document.getElementById("recog").style.display = "block";

    playVid();
}

function NoCamera() {

    document.getElementById("invitacion").style.display = "block";
    document.getElementById("init").style.display = "none";

    var vid = document.getElementById("invitacionVideo");
    vid.play();

    vid.addEventListener('ended', (event) => {
        document.getElementById("invitacion").style.display = "none";
        document.getElementById("confirmar").style.display = "block";
    });
}

function playVid() {
    var vid = document.getElementById("recogVideo");
    vid.play();

    vid.addEventListener('ended', (event) => {
        playInvVid();
    });
}

function playInvVid() {
    var vid = document.getElementById("invitacionVideo");
    document.getElementById("recog").style.display = "none";
    document.getElementById("invitacion").style.display = "block";
    /* getFullscreen(vid); */
    vid.play();

    vid.addEventListener('ended', (event) => {
        /* document.getElementById("invitacion").style.display = "none";
        document.getElementById("confirmar").style.display = "block"; */
        
        if(window.location.hash == "#1"){
            var newURL = window.location.origin+"/SuperBoda/invitacion/confirmar_mas_uno.html"+window.location.search;
            window.location.href = newURL;
        }
        else{
            var newURL = window.location.origin+"/SuperBoda/invitacion/confirmar.html"+window.location.search;
            window.location.href = newURL;
        }
    });
}

function getFullscreen(element) {
    if (element.requestFullscreen) {
        element.requestFullscreen();
    } else if (element.mozRequestFullScreen) {
        element.mozRequestFullScreen();
    } else if (element.webkitRequestFullscreen) {
        element.webkitRequestFullscreen();
    } else if (element.msRequestFullscreen) {
        element.msRequestFullscreen();
    }
}

function NoConfirm() {
    document.getElementById("confirmar").style.display = "none";
    document.getElementById("sinConfirmar").style.display = "block";
}