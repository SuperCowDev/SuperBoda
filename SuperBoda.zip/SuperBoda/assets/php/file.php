<?php
    $server = "localhost";
    $username = "supercow";
    $password = "Qwerty123";
    $dbname = "superboda";

    $connectionDB = new mysqli($server,$username,$password,$dbname);

    if($connectionDB->connect_error){
        die("Conexion fallida".$connectionDB->connect_error);
    }

    if(isset($_POST['text'])){
        $text = $_POST['text'];

        $sql = "INSERT INTO asistencia(ID,FechaConfirmacion) VALUES('$text',NOW())";

        if($connectionDB->query($sql) == TRUE){
            echo "Insertado correctamente";
        }else{
            echo "Error en el query";
        }
        header("location: index.php");
    }
    $connectionDB->close();
?>